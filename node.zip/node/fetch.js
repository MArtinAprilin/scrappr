
fetch("file:///home/martin/scraper.list/react/bruh.html").then(function(response){
   console.log(response.json()); 
}).then(function(response){
    debugger;   
})  